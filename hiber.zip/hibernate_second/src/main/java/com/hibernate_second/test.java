package com.hibernate_second;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class test {

	public static void main(String[] args) {
		StandardServiceRegistry ssr=new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();
	
		Metadata meta = new MetadataSources(ssr).getMetadataBuilder().build();
		SessionFactory fac=meta.getSessionFactoryBuilder().build();
		Session sss=fac.openSession();
		Transaction tr=sss.beginTransaction();
		student s=new student();
		s.setId(101);
		s.setName("Suresh");
		s.setCity("faridabad");
		s.setEmail("suresh@gmail.com");
		s.setPhone("9408494070");
		sss.save(s);
		System.out.println("Sucessfully saved!");
		tr.commit();
		sss.close();
	}
}